import java.util.Arrays;
class Student{
	private String studentId;
	private String name;

	Student(String studentId, String name){
		this.studentId=studentId;
		this.name=name;
	}
	public void setStudentId(String studentId){
		this.studentId=studentId;
	}
	public void setName(String name){
		this.name=name;
	}
	public String getStudentId(){
		return studentId;
	}
	public String getName(){
		return name;
	}
	public String toString(){
		return "StudentId:"+studentId+"\nName:"+name;
	}
}

class Courses{
	private String courseId;
	private String courseName;
	private Student[] students;
	private boolean[] attendance;
	
	Courses(String courseId,  String courseName, int size){
		this.courseId=courseId;
		this.courseName=courseName;
		this.students=new Student[size];
		this.attendance=new boolean[size];
	}
	public void enrollStudent(Student student){
		for(int i=0;i<students.length;i++){
			if(students[i]==null){
				students[i]=student;
				break;
			}
		}
	}
	public void markAttendance(String studentId, boolean isPresent){
		int c=0;
		for(int i=0;i<students.length;i++){
			if(students[i]!=null && students[i].getStudentId().equals(studentId)){
				attendance[i]= isPresent;
				c++;
				break;
			}
		}
		if(c==0){
			System.out.println("Student not found");
		}
	}
	public void displayAttendance(){
		System.out.println("Attendance for "+courseName+":");
		for(int i=0;i<students.length;i++){
			if(students[i]!=null){
				String status= attendance[i]?"Present":"Absent";
				System.out.println("Student ID:"+students[i].getStudentId()+",Status:"+status);
			}
		}
	}
	public void setCourseId(String courseId){
		this.courseId=courseId;
	}
	public void setCourseName(String courseName){
		this.courseName=courseName;
	}
	public Student[] getStudents(){
		return students;
	}
	public String getCourseId(){
		return courseId;
	}
	public String getCourseName(){
		return courseName;
	}
	
}

class AttendanceSystem{
	private Student[] students;
	private Courses[] courses;
	private int studentCount=0;
	private int courseCount=0;

	AttendanceSystem(int courseSize, int studentSize){
		this.students=new Student[studentSize];
		this.courses=new Courses[courseSize];
	}
	public void addStudent(Student student){
		if(studentCount<students.length){
			students[studentCount++]=student;
		}
		else{
			System.out.println("We dont have enough space");
		}
	}
	public void addCourse(Courses course){
		if(courseCount<courses.length){
			courses[courseCount++]=course;
		}
		else{
			System.out.println("We dont have enough space");
		}
	}
	public void markAttendance(String courseId,String studentId,boolean isPresent){
		for(Courses course:courses){
			if(course!=null && course.getCourseId().equals(courseId)){
				course.markAttendance(studentId, isPresent);
				break;
			}
		}
	}
	public void displayAttendance(String courseId){
		for(Courses course:courses){
			if(course!= null && course.getCourseId().equals(courseId)){
				course.displayAttendance();
				break;
			}
		}
	}
	
}

public class Test{
	public static void main(String[] args){
		Student s1=new Student("67","Vikashini");
		Student s2=new Student("68","Ravi");
		Student s3=new Student("69","Dev");

		Courses j=new Courses("BCS001", "Java", 5);
		Courses p=new Courses("BCS002", "Python", 6);

		j.enrollStudent(s1);
		j.enrollStudent(s2);
		j.enrollStudent(s3);
		p.enrollStudent(s1); 
		p.enrollStudent(s2);
		
		AttendanceSystem attendanceSystem=new AttendanceSystem(2,2);
		attendanceSystem.addStudent(s1);
		attendanceSystem.addStudent(s2);
		attendanceSystem.addStudent(s3);

		attendanceSystem.addCourse(j);
		attendanceSystem.addCourse(p);
		
		attendanceSystem.markAttendance("BCS001","S001",true);
		attendanceSystem.markAttendance("BCS001","S002",false);
		attendanceSystem.markAttendance("BCS002","S003",true);
		attendanceSystem.markAttendance("BCS002","S001",true);
		attendanceSystem.markAttendance("BCS002","ggg",true);

		attendanceSystem.displayAttendance("BCS001");
		attendanceSystem.displayAttendance("BCS002");

		System.out.println(Arrays.toString(j.getStudents()));

	}
}
